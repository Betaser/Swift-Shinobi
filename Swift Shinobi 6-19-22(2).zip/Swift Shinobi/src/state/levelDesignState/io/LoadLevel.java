package state.levelDesignState.io;

public class LoadLevel {
	
}
