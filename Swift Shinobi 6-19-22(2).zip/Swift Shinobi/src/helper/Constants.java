package helper;

public class Constants {
	
	public static final double UI_DEPTH = 0;
	public static final double EN_DEPTH = 1;

}
