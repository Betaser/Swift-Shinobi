package miscObjects;

public class SideCornerCollision {
	
	public Side side;
	public Corner corner;
	
	public SideCornerCollision(Side side, Corner corner) {
		this.side = side;
		this.corner = corner;
	}
	
}
