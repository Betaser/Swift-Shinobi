package levels;

import java.util.ArrayList;

public class Levels {
	
	ArrayList<Level> levels;
	
	public Levels() {
		levels = new ArrayList<>();
	}
	
}
