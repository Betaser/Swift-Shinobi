package ui;

public interface Controllable {
	
	void disableControls();
	void findControls();

}
